#include<stdio.h>

int Digitos(int N)
{
	int cont = 1; //cria e inicia a variavel cont com 1
	if (N >= 10) //se cont for maior que 10, ou seja, ainda não tivermos contado todos os digitos
	{
    	cont = cont + Digitos(N/10); //atualiza o valor de cont chamando novamente a função
  	}
	return cont; //retorna cont
}

int main()
{
	int N; //cria a variável N
	printf("Digite um numero inteiro: ");
	scanf("%d", &N); //instancia a variável N
	printf("Resultado: %d", Digitos(N)); //dá o resultado chamando a funçao Digitos
}

