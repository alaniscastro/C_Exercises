#include<stdio.h>

void dec2bin (int dec)
{
	if (dec >= 2) //se o número for maior ou igual a 2
	{ 	
    	dec2bin(dec/2); //chama a função novamente para o número soobre 2
		printf("%d", (dec%2)); //imprime o resto
  	}
	else
		printf("%d", (dec%2)); //caso seja menor que 2, também imprime o resto
}

int main()
{
	int dec; //declara a variavel decimal
	printf("Digite um numero inteiro: ");
	scanf("%d", &dec); //instancia a variavel decimal
	printf("Resultado: ");
	dec2bin(dec); //vai imprimir o resultado dentro da funcao dec2bin
}



