#include<stdio.h>

int mdc(int a, int b)
{
	if (b!=0) //se b for diferente de 0
	{
		/*int resto = a % b; //cria e inicia a variavel resto
		a = b; //a toma o valor de b
		b = resto; //b toma o valor do resto
		return mdc (a, b);	//chama a própria funçao de calculo do mdc, agora com novos valores*/
		return mdc(b, a%b); //a parte comentada acima pode ser otimizada dessa forma
	}
	else //se b for igual a 0, ou seja, já encontramos o mdc
	{
		return a; //retorna a (que é igual ao mdc)
	}
}

int main()
{
	int a, b; //cria as variaveis a e b
	printf("Digite dois numeros inteiros: ");
	scanf("%d%d", &a, &b); //instancia as variaveis a e b
	printf("Resultado: %d", mdc(a, b)); //dá o resultado do mdc atraves da chamada da função mdc
}
