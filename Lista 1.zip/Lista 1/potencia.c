#include<stdio.h>

int mult (int base, int exp)
{
	int cont =1; //cria e inicializa a variavel cont
	if (exp >= 1) //se o expoente for maior ou igual a 1, ou seja, ainda precisamos efetuar multiplicacoes
	{
		exp--; //subtrai um no expoente para atualizar seu valor
    	cont = base * mult(base, exp); //atualiza o valor de cont com o valor do novo resultado
  	}
	return (cont); //retorna o valor de cont
}

int main()
{
	int base, exp; //cria as variaveis base e expoente(exp)
	printf("Digite a base e o expoente inteiros: ");
	scanf("%d%d", &base, &exp); //instancia as variaveis
	printf("Resultado: %d", mult(base, exp)); //dá o resultado chamando a funçao mult
}


